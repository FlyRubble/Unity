﻿using System.Collections.Generic;
using UnityEngine;
using Framework.Event;

namespace UnityAsset
{
    public static class AssetManagerExtensions
    {
    }
}
