﻿
namespace Framework
{
    namespace UI
    {
        public enum Sibling
        {
            First = 1,
            Last = 2,
            Custom = 4,
        }
    }
}