﻿using UnityEngine;
using UnityEditor;
using NUnit.Framework;
using System.IO;
using Streetball;
using Streetball.Asset;
using System.Linq.Expressions;
using System;

public class ConfigTests
{
    private void TestAssetExist(string filename, string file)
    {
        var path = AssetBundlePathResolver.GetAssetRelativePath(file) + Streetball.Asset.AssetBundlePathResolver.GetAssetShortName(file);
        path = path.ToLower();
        path = Application.dataPath + "/" + path;
        Assert.IsTrue(File.Exists(path), "资源缺失: 文件 = " + filename + ", 资源 = " + file);
    }

    private void TestConfigFieldIsNull<T>(T field, string fieldName, string filename, int id)
    {
        Assert.IsTrue(field != null, "配置错误: 文件 = " + filename + ", 字段: " + fieldName + ", ID = " + id);
    }

    static string GetFieldName<T>(Expression<Func<T>> expression)
    {
        var me = expression.Body as MemberExpression;
        var name = me.Member.Name;
        return name;
    }

    [Test]
    public void static_check_model()
    {
        var filename = "/data/conf/model.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<ModelConfig.JsonModel>(text);

        foreach (var item in json.Model)
        {
            TestAssetExist(filename, item.underBody);
            TestAssetExist(filename, item.equipHead);
            TestAssetExist(filename, item.underBody);
            TestAssetExist(filename, item.equipBody);
            TestAssetExist(filename, item.shoes);
            TestAssetExist(filename, item.faceanger);
            TestAssetExist(filename, item.facesmile);
            TestAssetExist(filename, item.facecool);
            TestAssetExist(filename, item.icon1.Replace(".png", ".texture"));
            TestAssetExist(filename, item.pics1.Replace(".png", ".texture"));
            TestAssetExist(filename, item.whole.Replace(".png", ".texture"));

            if (item.voice != "0")
            {
                var voiceArray = item.voice.Split(';');
                for (var i = 0; i < voiceArray.Length; ++i)
                {
                    var test = "player/" + voiceArray[i] + ".audio";
                    TestAssetExist(filename, test);
                }
            }
        }
    }

    [Test]
    public void static_check_propItem()
    {
        var filename = "/data/conf/propItem.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<ItemConfig.JsonItem>(text);

        foreach (var item in json.item)
        {
            TestAssetExist(filename, item.Icon.Replace(".png", ".texture"));
        }

        foreach (var item in json.equip)
        {
            var fileList = new string[] { item.filenameM, item.filenameF, item.filenameMH };

            foreach (string file in fileList)
            {
                if (!string.IsNullOrEmpty(file))
                {
                    if (item.hasSkin)
                    {
                        for (int i = 1; i <= 2; ++i)
                        {
                            string fileTest = string.Format("icons.atlas/model/{0}_{1}.png", file, i);
                            if (fileTest.Contains("_mh_"))
                            {
                                continue;
                            }
                            TestAssetExist(filename, fileTest.Replace(".png", ".texture"));
                        }
                    }

                    string equipasset = string.Format("skin/{0}.model", file);
                    TestAssetExist(filename, equipasset);
                }
            }
        }
    }

    [Test]
    public void static_check_headportrait()
    {
        var filename = "/data/conf/headportrait.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<HeadConfig.JsonHead>(text);

        foreach (var item in json.HeadPortrait)
        {
            TestAssetExist(filename, item.icon.Replace(".png", ".texture"));
        }
    }

    [Test]
    public void static_check_field()
    {
        var filename = "/data/conf/field.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<FieldConfig.DataObject>(text);

        foreach (var item in json.itemList)
        {
            if (!string.IsNullOrEmpty(item.section))
            {
                TestAssetExist(filename, item.section.Replace(".png", ".texture"));
            }
            if (!string.IsNullOrEmpty(item.fieldModular))
            {
                TestAssetExist(filename, item.fieldModular.Replace(".png", ".texture"));
            }
            TestAssetExist(filename, item.model);
        }
    }

    [Test]
    public void static_check_ball()
    {
        var filename = "/data/conf/ball.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<BallConfig.JsonBall>(text);

        foreach (var item in json.list)
        {
            TestAssetExist(filename, item.model);
        }
    }

    [Test]
    public void static_check_club()
    {
        var filename = "/data/conf/club.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<ClubConfig.JsonClub>(text);

        foreach (var item in json.badgeres)
        {
            TestAssetExist(filename, item.resname.Replace(".png", ".texture"));
        }
    }

    [Test]
    public void static_check_propquest()
    {
        var filename = "/data/conf/propquest.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<TaskConfig.JsonData>(text);

        foreach (var item in json.propquest)
        {
            TestAssetExist(filename, item.icon.Replace(".png", ".texture"));
        }
    }

    [Test]
    public void static_check_skill()
    {
        var filename = "/data/conf/skillex.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<SkillConfig.JsonSkill>(text);

        foreach (var item in json.dataList)
        {
            if (!string.IsNullOrEmpty(item.icon))
            {
                TestAssetExist(filename, item.icon.Replace(".png", ".texture"));
            }

            TestConfigFieldIsNull(item.skillEffect, GetFieldName(() => item.skillEffect), filename, item.guid);
            TestConfigFieldIsNull(item.about, GetFieldName(() => item.about), filename, item.guid);
            TestConfigFieldIsNull(item.subject, GetFieldName(() => item.subject), filename, item.guid);
        }
    }

    [Test]
    public void static_check_simplemode()
    {
        var filename = "/data/conf/simlpemode.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<SimpleModelConfig.JsonSinpleModle>(text);

        foreach (var item in json.simlpeModeList)
        {
            TestAssetExist(filename, item.name);
        }
    }

    [Test]
    public void runtime_check_config_tests()
    {
        var configMap = ConfigMap.Instance;
        try
        {
            var list = configMap.configList;
            foreach (var kv in list)
            {
                var filename = "/data/conf/" + kv.Key;
                var text = File.ReadAllText(Application.dataPath + filename.Replace(".conf", ".json"));
                try
                {
                    kv.Value.Initialize(text);
                }
                catch (System.Exception e)
                {
                    Assert.Fail(string.Format("filename = {0}, exception:\n {1}", filename, e.ToString()));
                }
            }
        }
        catch (System.Exception e)
        {
            Assert.Fail(string.Format("initialize failed!, exception:\n {0}", e.ToString()));
        }
        configMap = null;
    }


    [Test]
    public void static_check_robotspeak()
    {
        var filename = "/data/conf/robotspeak.json";
        var text = File.ReadAllText(Application.dataPath + filename);
        var json = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<RobotSpeakConfig.JsonData>(text);

        foreach (var item in json.robotspeak)
        {
            int lenthWord = item.wordspool.Split('|').Length;
            int lenth1 = item.weight.Split('|').Length - 1;
            int lenth2 = item.weight1.Split('|').Length - 1;
            int lenth3 = item.weight2.Split('|').Length - 1;

            if (lenthWord != lenth1 || lenthWord != lenth2 || lenthWord != lenth3)
            {
                Assert.Fail("语言池 key: "+item.type+"  语言池长度与性格不符");
            }
            
        }
    }
}