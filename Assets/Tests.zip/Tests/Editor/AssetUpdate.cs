﻿using UnityEngine;
using System.Collections;
using Streetball;
using UnityEditor;

/// <summary>
/// Svn
/// </summary>
public class AssetUpdate : EditorWindow
{

    [MenuItem("AssetUpdate/Check")]
    public static void Check()
    {
        CheckUpdate();
    }

    [MenuItem("AssetUpdate/Update")]
    public static void Update()
    {
        BundleUpdate();
    }

    [MenuItem("AssetUpdate/Bundle")]
    public static void Bundle()
    {
        if (Selection.activeObject != null)
        {
            string rootPath = Application.dataPath + "/../verfile/";
            // 移除所有assetBundleName
            string[] assetBundleNames = AssetDatabase.GetAllAssetBundleNames();
            foreach (var assetBundleName in assetBundleNames)
            {
                AssetDatabase.RemoveAssetBundleName(assetBundleName, true);
            }
            var asset = AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(Selection.activeObject));
            asset.assetBundleName = "updatefilelist.conf";
            BuildPipeline.BuildAssetBundles(rootPath, BuildAssetBundleOptions.ChunkBasedCompression, buildTarget);
            // 移除所有assetBundleName
            assetBundleNames = AssetDatabase.GetAllAssetBundleNames();
            foreach (var assetBundleName in assetBundleNames)
            {
                AssetDatabase.RemoveAssetBundleName(assetBundleName, true);
            }
            AssetDatabase.Refresh();
        }
    }

    static void BundleUpdate()
    {
        string rootPath = Application.dataPath + "/../verfile/";

        string url = rootPath + "new/verfile.conf";
        AssetBundle assetBundle = AssetBundle.LoadFromFile(url);
        ResourceConfig jsonNew = new ResourceConfig();
        if (assetBundle != null)
        {
            Object o = assetBundle.LoadAsset("verfile");
            string data = o.ToString();
            jsonNew.Initialize(data);
            assetBundle.Unload(true);
        }

        url = rootPath + "old/verfile.conf";
        assetBundle = AssetBundle.LoadFromFile(url);
        ResourceConfig jsonOld = new ResourceConfig();
        if (assetBundle != null)
        {
            Object o = assetBundle.LoadAsset("verfile");
            string data = o.ToString();
            jsonOld.Initialize(data);
            assetBundle.Unload(true);
        }

        url = rootPath + "old/updatefilelist.conf";
        assetBundle = AssetBundle.LoadFromFile(url);
        ResourceConfig updateOld = new ResourceConfig();
        if (assetBundle != null)
        {
            Object o = assetBundle.LoadAsset("updatefilelist");
            string data = o.ToString();
            updateOld.Initialize(data);
            assetBundle.Unload(true);
        }

        url = Application.dataPath + "/../output/LTAutoBuild/";
        if (System.IO.Directory.Exists(rootPath + "data"))
        {
            System.IO.Directory.Delete(rootPath + "data", true);
        }
        foreach (var v in jsonNew.resourceConfDict)
        {
            if (jsonOld.resourceConfDict.ContainsKey(v.Value.file) && jsonOld.resourceConfDict[v.Value.file].md5 == v.Value.md5)
            {
                continue;
            }

            if (updateOld.resourceConfDict.ContainsKey(v.Value.file))
            {
                updateOld.resourceConfDict[v.Value.file] = v.Value;
            }
            else
            {
                updateOld.resourceConfDict.Add(v.Value.file, v.Value);
            }

            if (System.IO.File.Exists(url + v.Value.file))
            {
                System.IO.DirectoryInfo info = System.IO.Directory.GetParent(rootPath + v.Value.file);
                if (!info.Exists)
                {
                    System.IO.Directory.CreateDirectory(info.FullName);
                }
                System.IO.File.Copy(url + v.Value.file, rootPath + v.Value.file, true);
            }
            else
            {
                Debug.LogErrorFormat("文件找不到：{0}", url + v.Value.file);
            }
        }

        url = Application.dataPath + "/updatefilelist.json";
        var sw = new System.IO.StreamWriter(url);
        updateOld.json.patchList.Clear();
        foreach (var v in updateOld.resourceConfDict.Values)
        {
            updateOld.json.patchList.Add(v);
        }
        updateOld.json.patchList.RemoveAll((patch) => { return patch.file.Contains("updatefilelist") || patch.file.Contains("verfile"); });
        var updateFileListConfigText = Pathfinding.Serialization.JsonFx.JsonWriter.Serialize(updateOld.json);
        sw.Write(updateFileListConfigText);
        sw.Close();
        AssetDatabase.Refresh();
        
        string path = Application.dataPath + "/updatefilelist.json";
        // 移除所有assetBundleName
        string[] assetBundleNames = AssetDatabase.GetAllAssetBundleNames();
        foreach (var assetBundleName in assetBundleNames)
        {
            AssetDatabase.RemoveAssetBundleName(assetBundleName, true);
        }
        string relativePath = path.Replace(Application.dataPath, "Assets");
        var asset = AssetImporter.GetAtPath(relativePath);
        asset.assetBundleName = "updatefilelist.conf";
        BuildPipeline.BuildAssetBundles(rootPath, BuildAssetBundleOptions.ChunkBasedCompression, buildTarget);
        // 移除所有assetBundleName
        assetBundleNames = AssetDatabase.GetAllAssetBundleNames();
        foreach (var assetBundleName in assetBundleNames)
        {
            AssetDatabase.RemoveAssetBundleName(assetBundleName, true);
        }
        //AssetDatabase.DeleteAsset(path);
        AssetDatabase.Refresh();

        CheckUpdate();
    }

    static void CheckUpdate()
    {
        string rootPath = Application.dataPath + "/../verfile/";

        string url = rootPath + "new/verfile.conf";
        AssetBundle assetBundle = AssetBundle.LoadFromFile(url);
        ResourceConfig jsonNew = new ResourceConfig();
        if (assetBundle != null)
        {
            Object o = assetBundle.LoadAsset("verfile");
            string data = o.ToString();
            jsonNew.Initialize(data);
            assetBundle.Unload(true);
        }

        url = rootPath + "old/verfile.conf";
        assetBundle = AssetBundle.LoadFromFile(url);
        ResourceConfig jsonOld = new ResourceConfig();
        if (assetBundle != null)
        {
            Object o = assetBundle.LoadAsset("verfile");
            string data = o.ToString();
            jsonOld.Initialize(data);
            assetBundle.Unload(true);
        }

        foreach (var v in jsonNew.resourceConfDict)
        {
            if (jsonOld.resourceConfDict.ContainsKey(v.Value.file) && jsonOld.resourceConfDict[v.Value.file].md5 == v.Value.md5)
            {
                continue;
            }
            url = rootPath + v.Value.file;
            bool bExists = System.IO.File.Exists(url);
            if (!bExists)
            {
                Debug.LogError(v.Value.file);
            }
            else
            {
                Debug.Log(url);
            }
        }
        Debug.LogFormat("Check Finish!");
    }

    /// <summary>
    /// 打包目标平台
    /// </summary>
    /// <value>The build target.</value>
    static BuildTarget buildTarget
    {
        get
        {
            BuildTarget buildTarget = BuildTarget.StandaloneWindows64;//EditorUserBuildSettings.activeBuildTarget;
#if UNITY_ANDROID
			buildTarget = BuildTarget.Android;
#elif UNITY_IPHONE
			buildTarget = BuildTarget.iOS;
#elif UNITY_EDITOR_WIN && UNITY_EDITOR_64
            buildTarget = BuildTarget.StandaloneWindows64;
#elif UNITY_EDITOR_WIN && UNITY_EDITOR
			buildTarget = BuildTarget.StandaloneWindows;
#endif
            return buildTarget;
        }
    }
}