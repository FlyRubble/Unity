﻿using UnityEngine;
using UnityEditor;
using NUnit.Framework;
using System.IO;
using Streetball;
using Streetball.Asset;

public class AssetTests
{
    private static void CheckAssetsScripts(string path)
    {
        var guids = AssetDatabase.FindAssets("", new string[] { path });
        for (int index = 0; index < guids.Length; ++index)
        {
            var name = AssetDatabase.GUIDToAssetPath(guids[index]);
            if (name.EndsWith(".asset"))
            {
                UnityEngine.Object obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(name);
                Assert.IsTrue(null != obj, "path:" + path + ", missing script" + name);
            }
        }
    }

    [Test]
    public void static_check_player()
    {
        CheckAssetsScripts("Assets/data/asset/player");
    }

    [Test]
    public void static_check_shoot()
    {
        CheckAssetsScripts("Assets/data/asset/shoot");
    }
}