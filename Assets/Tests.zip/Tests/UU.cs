﻿using UnityEngine;
using System.Collections;
using Framework;
using System.Collections.Generic;

#if UNITY_EDITOR
using UnityEditor;
#endif

using Framework.UI;

public class UU : UIBase
{
    protected override void Awake()
    {
        base.Awake();
        Framework.Observer.instance.Notification(getName, Param.Create(new object[] { "log", "123456789" }));
        Framework.Observer.instance.Broadcast("TT", Param.Create(new object[] { "log", "asdfsadfasdf" }));

        foreach (var v in nName)
        {
            Debug.Log(v);
        }
        Framework.Observer.instance.AddNotification(this, "CC");
        foreach (var v in nName)
        {
            Debug.Log(v);
        }

        return;
        Debug.Log("Awake override 132331");

        Param p = Param.Create(new object[] { "k1", "v1", "k2", "v2", "k3"});
        Debug.Log(p["k1"]);
        Debug.Log(p["k2"]);
        Debug.Log(p["k3"]);
        Debug.Log(p.Count);
        p.Remove("k2");
        Debug.Log(p["k2"]);
        Debug.Log(p.Count);

        StartCoroutine("OnT");
    }

    IEnumerator OnT()
    {
        Debug.Log("bb");
        yield return new WaitForSeconds(3f);
        EditorApplication.isPaused = true;
        Debug.Log("aa");
    }
}
