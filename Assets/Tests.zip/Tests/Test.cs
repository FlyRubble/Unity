﻿using UnityEngine;
using System;
using System.Globalization;
using Streetball;

public class Test : MonoBehaviour {

	// Use this for initialization
	void Start () {
        //object o = new A();
        //A a = o as A;
        //Debug.Log(a.a);
        //Debug.Log(a.b);


        object o = 123;
        int i = (int)o;

        string s = "123";
        string ss = String.Intern("123");
        Debug.Log(string.ReferenceEquals(s, ss));
        Debug.Log(String.IsInterned("123"));
        Debug.Log(String.IsInterned("1230"));

        object oo;

        int? a = null;
        int b = a ?? 1;

        int c = 1;
        object d = 1;

        Debug.Log(c.CompareTo(d));
        Debug.Log(c.CompareTo(1));

        Debug.Log(c.Equals(d));
        Debug.Log(c.Equals(1));

        Debug.Log(c.ToString("C"));
        Debug.Log(c.ToString("C", CultureInfo.CreateSpecificCulture("en-US")));
        Debug.Log(c.ToString("C", CultureInfo.CreateSpecificCulture("fr-FR")));
        Debug.Log(c.ToString("C", CultureInfo.CreateSpecificCulture("vi-VN")));


        Debug.Log(a.HasValue);
        Debug.Log(a.GetValueOrDefault());
        Debug.Log(b);


        char? cc = null;
    }
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnGUI()
    {
        if (GUILayout.Button("1"))
        {
            MatchManager.Instance.UI.UpdateSkillDemo(0, 0, true);
        }
        if (GUILayout.Button("2"))
        {
            MatchManager.Instance.UI.SetSkillTrainingTutorial(null);
        }
        if (GUILayout.Button("3"))
        {
            MatchManager.Instance.UI.SetJoyStickButtonState(0);
        }
        if (GUILayout.Button("4"))
        {
            MatchManager.Instance.UI.SetShowInputVisible(true, 0);
        }
        if (GUILayout.Button("5"))
        {
            MatchManager.Instance.UI.SetShowButtonEnable(0, true);
        }
    }

    //void OnGUI()
    //{
    //    if (GUILayout.Button(""))
    //    {
    //        float time = Time.realtimeSinceStartup;
    //        Common.Text.Ini ini = new Common.Text.Ini();
    //        for (int i = 0; i < 10000; ++i)
    //        {
    //            ini.SetString(i.ToString(), "name", i.ToString());
    //            ini.SetString(i.ToString(), "md5", i.ToString());
    //            ini.SetString(i.ToString(), "hash", i.ToString());
    //            ini.SetInt(i.ToString(), "size", i);
    //            ini.SetString(i.ToString(), "assetPath", i.ToString());
    //            ini.SetString(i.ToString(), "dependentAsset", "aaaa?bbbb");
    //        }
    //        ini.Write("D://Config.ini");
    //        Debug.Log(Time.realtimeSinceStartup - time);

    //        time = Time.realtimeSinceStartup;
    //        ini = new Common.Text.Ini("D://Config.ini");
    //        for (int i = 0; i < 10000; ++i)
    //        {
    //            //string s = ini.GetString(i.ToString(), "name");
    //            //s = ini.GetString(i.ToString(), "md5");
    //            //s = ini.GetString(i.ToString(), "hash");
    //            //int ijk = ini.GetInt(i.ToString(), "size");
    //            //s = ini.GetString(i.ToString(), "assetPath");
    //            //s = ini.GetString(i.ToString(), "dependentAsset");
    //        }
    //        Debug.Log(Time.realtimeSinceStartup - time);
    //    }

    //    if (GUILayout.Button(""))
    //    {
    //        float time = Time.realtimeSinceStartup;
    //        ManifestConfig ini = new Common.Text.ManifestConfig();
    //        for (int i = 0; i < 10000; ++i)
    //        {
    //            Manifest m = new Manifest();
    //            m.name = i.ToString();
    //            m.assetPath = m.MD5 = m.hash = i.GetHashCode().ToString();
    //            m.size = i;
    //            m.directDependencies.Add("aaaa");
    //            m.directDependencies.Add("bbbb");
    //            ini.Add(m);
    //        }
    //        ini.Save("D://Config.xml");
    //        Debug.Log(Time.realtimeSinceStartup - time);

    //        time = Time.realtimeSinceStartup;
    //        ini = new Common.Text.ManifestConfig();
    //        ini.Load("D://Config.xml");
    //        Debug.Log(Time.realtimeSinceStartup - time);
    //    }
    //}
}
