﻿using UnityEngine;
using System.Collections.Generic;
using System;
using Streetball;
using Streetball.Asset;
using System.Collections;
using Pathfinding.Serialization.JsonFx;


using Framework;

public class TestA : MonoBehaviour {
    public class JsonPlayer
    {
        //球员基础属性表
        public List<ConfPlayer> itemList = new List<ConfPlayer>();
        //球员等级成长表
        public List<ConfPlayerLevel> levelList = new List<ConfPlayerLevel>();
        //球员特训等级成长表
        public List<ConfPlayerQuality> trainList = new List<ConfPlayerQuality>();
        //球员技能槽解锁表
        public List<ConfPlayerSlot> skillSlot = new List<ConfPlayerSlot>();
    }

    public float aaa = 0.5f;
    public static float aa {
        get { return m_a.aaa; }
    }
    static TestA m_a;
    void Awake()
    {
        m_a = this;

        Dictionary<int, int> dic = new Dictionary<int, int>();
        for (int i = 0; i < 100; ++i)
        {
            dic.Add(i, i);
        }

        //foreach (var i in dic)
        //{
        //    if (i.Key % 10 == 1)
        //    {
        //        dic.Remove(i.Key);
        //    }
        //}


        Framework.UI.UIManager.instance.OpenUI<UU>();

        //UU u = Framework.UI.UIManager.instance.GetUI<UU>();

        //if (u != null)
        //{
        //    float f = Time.realtimeSinceStartup;
        //    for (int i = 0; i < 1000; ++i)
        //    {
        //        u.gameObject.SetActive(true);
        //        u.gameObject.SetActive(false);
        //    }
        //    float m = Time.realtimeSinceStartup - f;
        //    Debug.Log(m);

        //    Transform Launch = GameObject.Find("Launch").transform;
        //    Transform EventSystem = GameObject.Find("EventSystem").transform;
        //    f = Time.realtimeSinceStartup;
        //    for (int i = 0; i < 1000; ++i)
        //    {
        //        SetLayer(u.transform, 5);
        //        SetLayer(u.transform, 31);
        //    }
        //    m = Time.realtimeSinceStartup - f;
        //    Debug.Log(m);
        //}

        //StartCoroutine("TT");
    }

    void OnGUI()
    {
        if (GUILayout.Button("test"))
        {
            UIManager.Instance.SendEvent("ui_page_get_reward", EventPageType.EPT_SHOW);
        }
        if (GUILayout.Button("+"))
        {
            Framework.UI.UIManager.instance.OpenUI<UU>();
        }

        if (GUILayout.Button("-"))
        {
            Framework.UI.UIManager.instance.CloseUI<UU>();
        }
    }

    void SetLayer(Transform tf, int layer)
    {
        tf.gameObject.layer = layer;
        for (int i = 0; i < tf.childCount; ++i)
        {
            //SetLayer(tf.GetChild(i), layer);
        }
    }

    IEnumerator TT()
    {
        yield return new WaitForSeconds(3);
        Framework.UI.UIManager.instance.CloseUI<UU>();
    }

    public class Json
    {
        System.String m_jsonString;
        System.Object m_jsonObject;

        public Json() { }
        public Json(string firstname, object lastname)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
        }
        public string FirstName { get; set; }
        public object LastName { get; set; }
    }
    public class JsonBall
    {
        public List<ConfBallItem0> list = new List<ConfBallItem0>();
    }

    public class ConfBallItem0
    {
        public int guid;
        private string m_model;
        public string model;
        public Dictionary<string, string> dic = new Dictionary<string, string>();

        public static string mna;
    }

    public class JsonItem
    {
        public List<ConfItem> item = new List<ConfItem>();
        public List<EquipConf> equip = new List<EquipConf>();
        public List<PropConf> prop = new List<PropConf>();
    }

    public static List<Json> Serialize(string str)
    {
        return null;
    }

    IEnumerator TestAA()
    {
        WWW www = new WWW("http://127.0.0.1/gameinfor.byte");
        yield return www;
        string s = www.text;
        Debug.Log(s);
    }

    void Test()
    {
        bi = 1;
        JsonItem saasdf = (JsonItem)(jr.Deserialize(0, typeof(JsonItem)));
        bi = 2;
    }

    void Update()
    {
        if (jr != null && bi == 1)
        {
            Debug.LogErrorFormat("index:{0}, SourceLength:{1}, progress:{2}", jr.index, jr.SourceLength, jr.index * 1f / jr.SourceLength);
            int bb00 = 9;
            bb00 = 10;
        }

        if (bi == 2)
        {
            int bb0 = 9;
            bb0 = 10;
            Debug.LogError(Time.realtimeSinceStartup - tttime);
            tttime = Time.realtimeSinceStartup;
            bi = 3;
        }
    }

    int bi = 0;
    TextAsset t;
    JsonReader jr;
    float tttime;
    // Use this for initialization



    void Start () {

        //return;
        //UnityEngine.Object ooo = Resources.Load("GameObject");
        //GameObject go = GameObject.Instantiate(ooo) as GameObject;
        //go.SetActive(false);
        //return;
        //StartCoroutine("TestAA");
        t = Resources.Load("ball") as TextAsset;
        string sst = t.text;
        //tttime = Time.realtimeSinceStartup;
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        //jr = (new JsonReader(sst));
        jr = (new JsonReader(sst));
        Debug.LogError(Time.realtimeSinceStartup - tttime);
        System.Threading.Thread tt = new System.Threading.Thread(Test);
        tt.Start();
        Debug.LogError(Time.realtimeSinceStartup - tttime);
        return;

        string stata = "{\"head\":\"setValue\",\"info\":\"{\"value\":10,\"key\":\"3DDepth\"}";
        stata = t.text;
        string aas;

            JsonBall saasdf = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<JsonBall>(t.text);
        //List<ConfBallItem0> list = Pathfinding.Serialization.JsonFx.JsonReader.Deserialize<List<ConfBallItem0>>(t.text);
        saasdf.list.ForEach((o)=> {
            ConfBallItem0 oo = o as ConfBallItem0;
            oo.model = o.guid.ToString() + "asdfasdf";
            oo.dic.Add(o.guid.ToString(), o.model);
            Debug.Log(((ConfBallItem0)o).guid);
        });
        saasdf.list.Add(saasdf.list[0]);
        string strs = Pathfinding.Serialization.JsonFx.JsonWriter.Serialize(saasdf.list);
        System.IO.File.WriteAllText(@"D://js.json", strs);
        return;
        t = Resources.Load("char") as TextAsset;
        string sss = "\"aa\"\"";
        sss = "";
        string str = "{\"head\":\"setValue\",\"info\":\"{\"value\":10,\"key\":\"3DDepth\"}";
        str = t.text;
        for (int i = 0; i < str.Length; i++)
        {
            switch (str[i])
            {
                case '{':
                    sss += str[i] + "\n";
                    break;
                case '}':
                    sss += str[i] + "\n";
                    break;
                case ',':
                    sss += str[i];
                    continue;
                case ':':
                    sss += str[i];
                    continue;
                case '\\': break;
                case '\"':
                    {
                        int _lock = 0;
                        for (; i < str.Length; i++)
                        {
                            switch (str[i])
                            {
                                case '\"':
                                    {
                                        ++_lock;
                                        sss += str[i];
                                    }break;
                                default: break;
                            }
                            if (_lock == 2)
                                break;
                        }
                    }break;
                default: break;
            }
        }
        Debug.Log(sss);


        return;
        //str = t.text;
        List<Json> json = Serialize(str);
        foreach (Json s in json)
        {
            Debug.Log(s.FirstName);
            if (s.LastName.GetType() == json.GetType())
            {
                List<Json> jsons = s.LastName as List<Json>;
                foreach (Json ss in jsons)
                {
                    Debug.Log("     " + ss.FirstName);
                    Debug.Log("     " + ss.LastName);
                }
            }
            else
                Debug.Log(s.LastName);
        }
        //Debug.Log(DeSerialize(json));
    }

    public static List<Json> Serialize(string str, Queue<object> quStr)
    {
        if (quStr == null)
        {
            string[] sArray = str.Split(new char[6] { '{', '}', ',', ':', '\"', '\\' }, StringSplitOptions.RemoveEmptyEntries);
            string s = "";
            foreach (var ss in sArray)
            {
                s += ss;
            }
            Debug.Log(s);
            quStr = new Queue<object>();
            for (int i = 0; i < sArray.Length; i++)
                if (sArray[i] != "\"")
                {
                    int a;
                    if (int.TryParse(sArray[i], out a))
                        quStr.Enqueue(a);
                    else
                        quStr.Enqueue(sArray[i]);
                }
        }
        List<Json> json = new List<Json>();
        json.Add(new Json());
        for (int i = 0; i < str.Length; i++)
        {
            switch (str[i])
            {
            case '{':
                Stack<char> parentheses = new Stack<char>();
                parentheses.Push('{');
                int j = i;
                while (parentheses.Count > 0)//找到与之匹配的反括号的位置
                {
                    j++;
                    if (str[j] == '}')
                        parentheses.Pop();
                    if (str[j] == '{')
                        parentheses.Push('{');
                }
                if (json[json.Count - 1].FirstName == null)
                    json = Serialize(str.Substring(i + 1, j - i - 1), quStr);
                else
                    json[json.Count - 1].LastName = Serialize(str.Substring(i + 1, j - i - 1), quStr);//解析括号里的json数据
                i = j;
                break;
            case ',':
                json[json.Count - 1].LastName = quStr.Dequeue();
                json.Add(new Json());
                continue;
            case ':':
                json[json.Count - 1].FirstName = quStr.Dequeue().ToString();
                continue;
            case '\\': continue;
            case '\"': continue;
            default: continue;
            }
        }
        if (quStr.Count > 0)
            json[json.Count - 1].LastName = quStr.Dequeue();
        return json;
    }
}
