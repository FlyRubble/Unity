﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class TxT : Text
{
    readonly UIVertex[] m_TempVerts = new UIVertex[4];
    /// <summary>
    /// 绘制模型
    /// </summary>
    /// <param name="toFill"></param>
    protected override void OnPopulateMesh(VertexHelper toFill)
    {
        m_DisableFontTextureRebuiltCallback = true;

        Vector2 extents = rectTransform.rect.size;

        var settings = GetGenerationSettings(extents);
        cachedTextGenerator.Populate(text, settings);

        Rect inputRect = rectTransform.rect;

        // get the text alignment anchor point for the text in local space
        Vector2 textAnchorPivot = GetTextAnchorPivot(alignment);
        Vector2 refPoint = Vector2.zero;
        refPoint.x = (textAnchorPivot.x == 1 ? inputRect.xMax : inputRect.xMin);
        refPoint.y = (textAnchorPivot.y == 0 ? inputRect.yMin : inputRect.yMax);

        // Determine fraction of pixel to offset text mesh.
        Vector2 roundingOffset = PixelAdjustPoint(refPoint) - refPoint;

        // Apply the offset to the vertices
        IList<UIVertex> verts = cachedTextGenerator.verts;
        float unitsPerPixel = 1 / pixelsPerUnit;
        //Last 4 verts are always a new line...
        int vertCount = verts.Count - 4;

        toFill.Clear();

        for (int m = 0; m < vertCount; m++)
        {
            if (text[m / 4] == '0')
            {
                UIVertex tempVertex = verts[m];
                tempVertex.uv0 = Vector2.zero;
                verts[m] = tempVertex;
            }
        }


        if (roundingOffset != Vector2.zero)
        {
            for (int i = 0; i < vertCount; ++i)
            {
                int tempVertsIndex = i & 3;
                m_TempVerts[tempVertsIndex] = verts[i];
                m_TempVerts[tempVertsIndex].position *= unitsPerPixel;
                m_TempVerts[tempVertsIndex].position.x += roundingOffset.x;
                m_TempVerts[tempVertsIndex].position.y += roundingOffset.y;
                if (tempVertsIndex == 3)
                    toFill.AddUIVertexQuad(m_TempVerts);
            }
        }
        else
        {
            float x = 0;
            float y = 0;
            CharacterInfo info;
            for (int i = 0; i < vertCount; ++i)
            {
                int tempVertsIndex = i & 3;
                m_TempVerts[tempVertsIndex] = verts[i];

                if (!m_TempVerts[tempVertsIndex].uv0.Equals(Vector2.zero))
                {
                    char c = text[i / 4];
                    if (font.GetCharacterInfo(text[i/4], out info, 16))
                    {
                        Debug.LogFormat("{0}:{1}", c, info.uvTopRight.x - info.uvTopLeft.x);
                        Debug.LogFormat("{0}:{1}", c, info.uvTopRight.y - info.uvBottomRight.y);
                    }
                    switch (tempVertsIndex)
                    {
                    case 0:
                    {
                        if (x + Mathf.Max(info.uvBottomRight.x, info.uvTopRight.x) > extents.x)
                        {
                            x = 0;
                            y += fontSize;
                        }

                        //m_TempVerts[tempVertsIndex].position.x = x  - 7;
                        //m_TempVerts[tempVertsIndex].position.y = y;
                        //Debug.LogFormat("{0}:{1}", i, info.uvTopLeft);
                    }
                    break;
                    case 1:
                    {
                        //m_TempVerts[tempVertsIndex].position.x = x + 7;
                        //m_TempVerts[tempVertsIndex].position.y = y;
                        //Debug.LogFormat("{0}:{1}", i, info.uvTopRight);
                    }
                    break;
                    case 2:
                    {
                        //m_TempVerts[tempVertsIndex].position.x = x + 7;
                        //m_TempVerts[tempVertsIndex].position.y = y;
                        //Debug.LogFormat("{0}:{1}", i, info.uvBottomRight);

                        x += info.uvTopRight.x;
                    }
                    break;
                    case 3:
                    {
                        //m_TempVerts[tempVertsIndex].position.x = x - 7;
                        //m_TempVerts[tempVertsIndex].position.y = y;
                        //Debug.LogFormat("{0}:{1}", i, info.uvBottomLeft);

                    }
                    break;
                    }
                }
                //Debug.LogFormat("{0}:{1}", i, m_TempVerts[tempVertsIndex].position);

                m_TempVerts[tempVertsIndex].position *= unitsPerPixel;
                if (tempVertsIndex == 3)
                {
                    toFill.AddUIVertexQuad(m_TempVerts);
                }
            }
        }

        //计算标签 计算偏移值后 再计算标签的值
        List<UIVertex> vertsTemp = new List<UIVertex>();
        for (int i = 0; i < vertCount; i++)
        {
            UIVertex tempVer = new UIVertex();
            toFill.PopulateUIVertex(ref tempVer, i);
            vertsTemp.Add(tempVer);
        }

        m_DisableFontTextureRebuiltCallback = false;
    }
}